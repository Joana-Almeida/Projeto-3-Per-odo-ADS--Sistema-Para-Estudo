import Tkinter as tk

class tkinter:
    def __init__(self, master=None):
        self.fontePadrao = ("Arial", "10")
        self.primeiroContainer = Frame(master)
        self.primeiroContainer["pady"] = 10
        self.primeiroContainer.pack()

        self.segundoContainer = Frame(master)
        self.segundoContainer["padx"] = 10
        self.segundoContainer.pack()

        self.terceiroContainer = Frame(master)
        self.terceiroContainer["padx"] = 10
        self.terceiroContainer.pack()

        self.quartoContainer = Frame(master)
        self.quartoContainer["pady"] = 10
        self.quartoContainer.pack()

        self.titulo = Label(self.primeiroContainer, text="Cadastro de Assuntos")
        self.titulo["font"] = ("Arial", "20", "bold")
        self.titulo.pack()

        self.idLabel = Label(self.segundoContainer,text="Id", font=self.fontePadrao)
        self.idLabel.pack(side=LEFT)
        self.id = Entry(self.segundoContainer)
        self.id["width"] = 20
        self.id["font"] = self.fontePadrao
        self.id.pack(side=LEFT)

        self.temaLabel = Label(self.terceiroContainer, text="Tema", font=self.fontePadrao)
        self.temaLabel.pack(side=LEFT)
        self.tema = Entry(self.terceiroContainer)
        self.tema["width"] = 20
        self.tema["font"] = self.fontePadrao
        self.tema.pack(side=LEFT)

        self.descricao = Entry(self.quartoContainer)
        self.descricao["width"] = 40
        self.descricao["font"] = self.fontePadrao
        self.descricao.pack(side=LEFT)

        self.botao = Button (self.quartoContainer, text="Salvar")
        self.botao.pack(side=LEFT)

        self.botao_cancelar = Button (self.quartoContainer,text="Cancelar")
        self.botao_cancelar.pack(side=LEFT)

app=tk()
app.title("Cadastro de Assuntos")
app.geometry("900x500")
app.configure(background="#87CEFA")
app.mainloop()